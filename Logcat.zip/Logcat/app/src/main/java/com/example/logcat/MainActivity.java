package com.example.logcat;

import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private BroadcastReceiver timeChangeReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 버튼 초기화
        Button startButton = findViewById(R.id.startButton);

        // 버튼 클릭 이벤트 설정
        startButton.setOnClickListener(v -> {
            Toast.makeText(this, "Monitoring started", Toast.LENGTH_SHORT).show();
            monitorAntiForensicActions();
        });
    }

    private void monitorAntiForensicActions() {
        // 브로드캐스트 리시버를 설정하여 시간 및 날짜 변경 이벤트를 감지
        timeChangeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (Intent.ACTION_TIME_CHANGED.equals(action) || Intent.ACTION_DATE_CHANGED.equals(action)) {
                    String logMessage = "Anti-forensic event detected: " + action;
                    saveLogToDocuments(logMessage);
                }
            }
        };

        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_TIME_CHANGED);
        filter.addAction(Intent.ACTION_DATE_CHANGED);
        registerReceiver(timeChangeReceiver, filter);
    }

    private void saveLogToDocuments(String content) {
        // ContentResolver를 사용하여 MediaStore에 접근
        ContentResolver resolver = getContentResolver();

        // 타임스탬프 기반 파일명 생성
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String fileName = "Log_" + timestamp + ".txt";

        // 파일 메타데이터 설정
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName); // 파일 이름
        values.put(MediaStore.MediaColumns.MIME_TYPE, "text/plain"); // 파일 MIME 타입
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, "Documents/Logs"); // 저장 경로

        // MediaStore에 파일 삽입
        Uri uri = resolver.insert(MediaStore.Files.getContentUri("external"), values);

        if (uri != null) {
            try (OutputStream outputStream = resolver.openOutputStream(uri)) {
                if (outputStream != null) {
                    // 파일에 데이터 쓰기
                    outputStream.write(content.getBytes());
                    Toast.makeText(this, "Log saved: " + fileName, Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "Error saving log: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(this, "Failed to create log file", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 브로드캐스트 리시버 해제
        if (timeChangeReceiver != null) {
            unregisterReceiver(timeChangeReceiver);
        }
    }
}
